"""
Testing that functions from compat work as expected
"""
